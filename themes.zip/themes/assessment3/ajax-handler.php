<?php
// ajax-handler.php

function get_post_image_by_title($title) {
    // Convert title to lowercase and sanitize
    $category = sanitize_title(strtolower($title));

    $args = array(
        'category_name' => $category,
        'posts_per_page' => 1,
    );

    $query = new WP_Query($args);

    if ($query->have_posts()) {
        $query->the_post();
        echo get_the_post_thumbnail_url(get_the_ID());
    } else {
        echo 'nothing found'; // Return an empty string if no post is found
    }

    wp_reset_postdata();
}

if (isset($_POST['action']) && $_POST['action'] == 'get_post_image' && isset($_POST['title'])) {
    $title = sanitize_text_field($_POST['title']);
    get_post_image_by_title($title);
}


if (isset($_POST['action']) && $_POST['action'] == 'get_post_image' && isset($_POST['title'])) {
    error_log('Received title: ' . $_POST['title']);
    $title = sanitize_text_field($_POST['title']);
    get_post_image_by_title($title);
}
?>
