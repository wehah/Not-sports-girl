<!DOCTYPE html>
<html lang="en">

   <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <?php wp_head(); ?>
      <link rel="stylesheet" href="bootstrap-icons.svg">



      <title>Assessment - 3</title>

   </head>

   <body>

      <!-- ================================================================================== -->

      <!-- NAVBAR -->

      <!-- ================================================================================== -->

      <nav class="nav navbar-light bg-white  border-0 pt-1 MainNavBar">
         <div class="container  bg-transparent border-0 position-relative ">
            <div class="row   pt-4 pb-0 d-flex justify-content-between  slickBorderTop">
               <!-- ///////////////////////////////////////NAV TOP /////////////////////////////////// -->
               <!-- ColA -->
               <div class="col-lg-7 col-md-8 col-sm-6  order-lg-0 order-md-0 order-sm-0 ">
                  <div class="row ">
                     <!-- mini-row-Col-1 -->
                     <div class="col-lg-6 col-md-12 col-sm-12   d-flex align-items-center m-0 pb-2">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img
                              class="w-60  d-flex justify-content-center"
                              src="<?php echo get_template_directory_uri(); ?>/assets/brand/sportsGirl.png"></a>
                     </div>
                     <!-- mini-row-Col-2 -->
                     <div class="col-6 storeFinder d-none d-lg-flex">
                        <a href=""> <img class="w-30 mb-3 img-fluid p-2"
                              src="<?php echo get_template_directory_uri(); ?>/assets/icons/storeFinder.svg"></a>
                        <h4>FIND A STORE</h4>
                     </div>
                  </div>
               </div>
               <!-- ColB -->
               <div
                  class="col-12 col-lg-3 col-md-11 col-sm-11  d-flex align-items-center     order-lg-1 order-md-2 order-sm-2">
                  <!-- search bar -->
                  <div class="card w-100  searchCol bg-transparent border-0">
                     <form class="custom-search-input" role="search" method="get" action="<?php echo get_site_url() ?>">
                        <input class="form-control shadow-none" type="search" name="s" placeholder="SEARCH">
                        <button class="icon_s border-0 bg-transparent" type="submit">
                           <img class="w-100  p-2 img-fluid"
                              src="<?php echo get_template_directory_uri(); ?>/assets/icons/search.svg">
                        </button>
                     </form>
                  </div>
                  <!-- search bar -->
               </div>
               <!-- ColC -->
               <div
                  class="col-10 col-lg-2 col-md-4 col-sm-6 d-flex align-items-center   order-lg-2 order-md-1 order-sm-1   colC ">
                  <!-- icons -->
                  <div class="col-12 bg-transparent border-0    d-flex justify-content-between">


                     <a href=""> <img class="w-10 p-2"
                           src="<?php echo get_template_directory_uri(); ?>/assets/icons/Vector.svg"></a>

                     <a href=""> <img class="w-10 p-2"
                           src="<?php echo get_template_directory_uri(); ?>/assets/icons/Vector-1.svg"></a>

                     <a href=""> <img class="w-10   p-2"
                           src="<?php echo get_template_directory_uri(); ?>/assets/icons/Vector-2.svg"></a>

                  </div>
               </div>


               <!-- //////////////////////NAV BOTTOM ////////////////////////////////////////////////////////////-->
               <!-- ColD -->
               <!-- small screens -->
               
               <div id="menu"  class="col-11  collapse menu d-lg-none justify-content-lg-center border-top order-4 order-lg-5">
                  <div class="row m-0 mt-1 accordion  w-100  custom-absolute customcsss" id="testNavAccordion">
                     <?php
                     $menu_items = wp_get_nav_menu_items('testNav');
                 
                     if ($menu_items):
                         $parent_items = []; // Array to store parent items
                         $child_items = [];  // Array to store child items
                 
                         // Loop through to find and store parent and child items
                         foreach ($menu_items as $menu_item):
                             if (empty($menu_item->menu_item_parent)) {
                                 // Store parent item
                                 $parent_items[] = $menu_item;
                             } elseif (isset($child_items[$menu_item->menu_item_parent])) {
                                 // Store child item
                                 $child_items[$menu_item->menu_item_parent][] = $menu_item;
                             } else {
                                 // Create a new array for the child items of this parent
                                 $child_items[$menu_item->menu_item_parent] = [$menu_item];
                             }
                         endforeach;
                 
                         // Loop through to print parent items and their child items
                         foreach ($parent_items as $parent_item):
                             $post_id = $parent_item->object_id;
                             $thumbnail_url = get_the_post_thumbnail_url($post_id);
                             $category_color = get_post_meta($post_id, 'colour', true);
                             ?>
                     <div class="col-lg col-md-12   position-relative border-0 p-0">
                        <h4 class="p-0 m-0" id="heading-<?php echo $parent_item->ID; ?>">
                           <button class="accordion-button collapsed bg-transparent border-0 btnClass m-0"
                              type="button" data-bs-toggle="collapse"
                              data-bs-target="#collapse-<?php echo $parent_item->ID; ?>"
                              aria-controls="collapse-<?php echo $parent_item->ID; ?>">
                              <span class="  text-uppercase border-0">
                                 <h4>
                                    <?php echo esc_html($parent_item->title); ?>
                                 </h4>
                              </span>
                           </button>
                        </h4>
                        <div id="collapse-<?php echo $parent_item->ID; ?>"
                           class="accordion-collapse collapse  subMenu w-100 p-0"
                           aria-labelledby="heading-<?php echo $parent_item->ID; ?>" data-bs-parent="#testNavAccordion">
                           <div class="accordion-body p-0 m-0">
                              <div class="row m-0  childRow ">
                                 <?php
                                             // Check if there are child items for this menu item
                                             if (isset($child_items[$parent_item->ID])):
                                                 ?>
                                 <ul>
                                    <?php
                                                     // Loop through the child items
                                                     foreach ($child_items[$parent_item->ID] as $child_item):
                                                         //  child item HTML here
                                                         ?>

                                    <div class="col custHover">
                                       <a href="<?php echo esc_url($child_item->url); ?>">
                                          <h4 id="heading-<?php echo $parent_item->ID; ?>"
                                             class="text-uppercase p-2 pt-3 pb-3 text-left">
                                             <?php echo esc_html($child_item->title); ?>
                                          </h4>
                                       </a>
                                    </div>

                                    <?php endforeach; ?>
                                 </ul>
                                 <?php endif; ?>
                              </div>
                           </div>
                        </div>
                     </div>
                     <?php
                         endforeach;
                     endif;
                     ?>
                  </div>

               </div>

               <!-- large screen menu items -->
               <div id="menu2" class="col-12 collapse menu d-none   d-lg-flex  justify-content-lg-center mt-lg-2 order-5 order-lg-3 customcss2 " >

                
      
                  <!-- the mini-row div-->
                  <div class="row w-100  custom-absolute  gap-2 border-0 position-relative greatGrandParent"
                     id="testNavAccordion">
                     <?php
                     $menu_items = wp_get_nav_menu_items('testNav');
                     
                     if ($menu_items):
                         $parent_items = []; // Array to store parent items
                         $child_items = [];  // Array to store child items
                         $grandchild_items = [];  // Array to store grandchild items
                     
                         // Loop1
                         foreach ($menu_items as $menu_item):
                             if (empty($menu_item->menu_item_parent)) {
                                 // Store parent item
                                 $parent_items[] = $menu_item;
                             } elseif (isset($child_items[$menu_item->menu_item_parent])) {
                                 // Store child item
                                 $child_items[$menu_item->menu_item_parent][] = $menu_item;
                             } else {
                                 // Create a new array for the child items of this parent
                                 $child_items[$menu_item->menu_item_parent] = [$menu_item];
                             }
                         endforeach;
                     
                         // Loop2
                         foreach ($child_items as $parent_id => $children) {
                             foreach ($children as $child_item) {
                                 if (isset($child_items[$child_item->ID])) {
                                     // Store grandchild items
                                     $grandchild_items[$child_item->ID] = $child_items[$child_item->ID];
                                 }
                             }
                         }
                     
                         // Loop3
                         foreach ($parent_items as $parent_item):
                             $post_id = $parent_item->object_id;
                             $thumbnail_url = get_the_post_thumbnail_url($post_id);
                             $category_color = get_post_meta($post_id, 'colour', true);
                             $parent_item_title = $parent_item->title;
                     
                             // Output the clear text title
                             
                     
                             // If you want to use var_dump for debugging purposes, you can keep the following line
                             // var_dump($parent_item_title);
                          ?>
      
                     <!-- buttons -->
                     <div class="col col-lg col-md-12 border-0 p-0 ">
                        <div class="buttonsStyler w-100 d-flex justify-content-lg-between border-0">
                           <div class="w-100 border-0 bg-transparent m-0 p-0 parent-item"
                              data-parent-id="<?php echo $parent_item->ID; ?>">
                              <button class="w-100 border-0 bg-transparent"> 
                              <h4 class="text-uppercase p-0 pt-3 pb-3 m-0 border-0 m-0 p-0">
                                 <?php echo esc_html($parent_item->title); ?>
                              </h4>
                           </button>
      
      
                              <!-- child menu items-->
      
                              <div class="col col-lg col-md-12 border-0 p-0 position-absolute z-3 w-100 bg-light child-items"
                                 data-parent-id="<?php echo $parent_item->ID; ?>">
                                 <div class="row p-3 m-0 slickBorder">
                                    <?php
                                       // Check if there are child items for this menu item
                                       if (isset($child_items[$parent_item->ID])):
                                       
                                           ?>
      
                                    <ul>
                                       <!-- parent row -->
                                       <div class="row">
                                          <!-- first row -->
                                          <div class="col-4">
                                             <div class="row">
                                                <?php foreach ($child_items[$parent_item->ID] as $child_item): ?>
                                                <?php
                                                    $category = get_category_by_slug($child_item->title);
                                            
                                                    // Check if the title matches a category name
                                                    if ($category) {
                                                        $link = get_category_link($category->term_id);
                                                        $category_link = get_category_link($category->term_id);
                                                    } else {
                                                        // If the title doesn't match a category, check if it matches a post title
                                                        $post = get_page_by_title($child_item->title, OBJECT, 'post');
                                            
                                                        if ($post) {
                                                            $link = get_permalink($post->ID);
                                                        } else {
                                                            // Provide a default link if neither category nor post is found
                                                            $link = '#';
                                                        }
                                                    }
                                                    ?>
                                                <div class="col-12 custHover first-column"
                                                   data-category="<?php echo esc_attr($child_item->title); ?>"
                                                   data-category-id="<?php echo esc_attr($child_item->ID); ?>"
                                                   id="heading-<?php echo $child_item->ID; ?>">
                                                  
                                                   <a href="<?php echo esc_url($link); ?>">
                                                      <h4 class="text-uppercase p-2 pt-0 pb-0 mt-3 mb-3 text-start ">
                                                        
                                                         <span class=" pb-3 arrow bold-font-weight ">→</span>
                                                        <span class="sub-button">  <?php echo esc_html($child_item->title); ?></span>
                                                         
                                                      </h4>
                                                   </a>
                                                </div>
      
                                                <?php 
                                               
                                                 
                                                endforeach; 
                                                ?>
                                             </div>
      
                                          </div>
                             
                                          <!-- third col -->
                                          <div class="col-8">
      
                                             
      
                                             <div class="row d-flex justify-content-center">
                                                <h4 class="theTitle text-center mb-0" data-parent-id="<?php echo $parent_item->ID; ?>">
                                                    <span class=" borderCustom"> Here are some of the hottest items in our
                                                        <a href="<?php echo $category_link; ?>">
                                                            <strong class="text-uppercase">
                                                                <?php echo $parent_item_title; ?>
                                                            </strong>
                                                        </a> category
                                                    </span>
                                                </h4>
                                            
                                                <?php
                                                // Getting the category ID
                                                $category = get_term_by('name', $parent_item_title, 'category');
                                                if ($category) {
                                                    $category_id = $category->term_id;
                                            
                                                    // Get the category slug using the category ID
                                                    $category_slug = get_term_field('slug', $category_id, 'category');
                                            
                                                    // Getting the posts without affecting global post data
                                                    $custom_query_args = array(
                                                        'category_name'  => $category_slug,
                                                        'posts_per_page' => 3,
                                                    );
                                            
                                                    $custom_posts = get_posts($custom_query_args);
                                            
                                                    foreach ($custom_posts as $post) :
                                                        setup_postdata($post);
                                                        ?>
                                                        <!-- Your custom loop content here -->
                                                        <div class="col-4 p-3 pb-0 tweenTarget" data-parent-id="<?php echo $parent_item->ID; ?>">
                                                         <div class="row">
                                                             <div class="col-12 carD p-0" id="cards">
                                                                 <div class="card border-0 P-0 position-relative">
                                                                     <a href="<?php the_permalink(); ?>">
                                                                         <img class="card-img-top svgparent"
                                                                              src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="">
                                                                     </a>
                                                                 </div>
                                         
                                                                 <div class="card border-0 p-0 pt-1 bg-transparent">
                                                                     <h4 class="text-center text-uppercase">
                                                                         <?php the_title(); ?>
                                                                     </h4>
                                                                 </div>
                                                             </div>
                                                         </div>
                                                     </div>
                                                        <?php
                                                    endforeach;
                                            
                                                    // Reset the custom query
                                                    wp_reset_postdata();
                                                }
                                                ?>
                                            </div>                                  
                                                     
                                          </div>
      
                                       </div>
                                    </ul>
      
                                    <?php
                                    wp_reset_postdata();
                                    endif;
                                     ?>
                                     
                                 </div>
                              </div>
      
                           </div>
                        </div>
                     </div>
      
      
      
      
      
                     <?php
                          endforeach;
                      endif;
                      ?>
                      <?php wp_reset_postdata(); ?>
                  </div>
      
               </div>

               <!-- ColE -->
               <div id="menuButton"
                  class="col-2 col-md-1 col-sm-1  bg-transparent  d-flex  d-lg-none d-md-flex d-sm-flex align-items-center justify-content-end order-3 order-md-3 order-sm-3 p-2"
                  aria-expanded="false" data-target="#menu" data-toggle="collapse">
                  <button class="card bg-transparent border-0 ">
                     <img class="w-100  " style="max-width: 50px;"
                        src="<?php echo get_template_directory_uri(); ?>/assets/icons/h-menu.svg">
                  </button>
               </div>

            </div>
         </div>
      </nav>

      <!-- ================================================================================== -->