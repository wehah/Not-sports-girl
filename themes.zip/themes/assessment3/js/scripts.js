(function ($) {


   //==================================================================================
   // GET THE PATH TO THE THEME FOLDER 
   //==================================================================================
   /*
   if needed you can get the theme folder path which is stored in the var wpPath.theme 
   check functions.php for more details 
   */

//    console.log(wpPath.theme);



   //==================================================================================
   // BOOTSTRAP NAVBAR ENABLE DROPDOWN ON HOVER
   //==================================================================================
   /*
   Standard bootstrap menu does not support dropdown on hover, only on click. This code simulates a click by doing the things bootstrap does, on hover. 
   http://stackoverflow.com/questions/8878033/how-to-make-twitter-bootstrap-menu-dropdown-on-hover-rather-than-click

   This feature is disabled for this theme. On this site, it is better UX to have them display on click only. 
   -------------------------------------------------
   Should you want to enable this, uncomment the code below. There is nothing to configure. If you have a bootstrap-wordpress navbar, it just works. 
   -------------------------------------------------
   */

   /*
      $(".dropdown").hover(
         function () {
            $(this).addClass('open')
         },
         function () {
            $(this).removeClass('open')
         }
      );
      
     //  
   */

   // MOBILE MENU
   // $(document).ready(function() {
   //    $("#mobileMenu").click(function() {
   //       console.log("CLICKED");
   //    //   $("#menu").toggleClass('d-md-flex')
   //      $("#menu").toggle("visible");
   //    //   $("#menu").toggleClass('d-sm-flex')

   //    //   $("#menu").toggleClass('custom-sm')

   //    });
   //  });


//    TOWEENS AND ANIMATIONS





   // FOR MOBILE MENU
   $(document).ready(function() {
      function activateSmallScreenMenu() {
          $("#menuButton").click(function(event) {
              $("#menu").toggle("visible");
              $("#menuButton").attr("aria-expanded", $("#menu").is(":visible"));
              event.stopPropagation();
          });
  
          $(document).click(function(event) {
              if (!$(event.target).is("body") && !$(event.target).closest("#menu, #menuButton").length) {
                  console.log("If the body is clicked and except the menu and menu button, close the menu");
                  $("#menu").hide();
                  $("#menuButton").attr("aria-expanded", "false");
              }
          });
      }
  
    //   the new menu bottons
    $(document).ready(function () {
        // Add 'hidden' class to all child items initially
        $(".child-items").addClass("hidden");
        

        // Handle hover effect on parent items
        $(".parent-item").mouseenter(function () {
            var parentID = $(this).data("parent-id");
            $(".child-items[data-parent-id='" + parentID + "']").removeClass("hidden");
            
            // GSAP Tween
            var tl0 = gsap.timeline({});
            tl0.fromTo(".theTitle[data-parent-id='" + parentID + "']", {rotationX:0, opacity: 0, x: 20}, {opacity: 1, x: 0, rotationX:0, duration:0.5 });
            tl0.fromTo(".tweenTarget[data-parent-id='" + parentID + "']", {opacity: 0, x: -20}, {x: 0, stagger: 0.2, opacity: 1, duration:0.5, ease: "back.out(7.5)"}, "=-.5" );
            console.log($(".theTitle[data-parent-id='" + parentID + "']"));  

        }).mouseleave(function () {
            var parentID = $(this).data("parent-id");
            $(".child-items[data-parent-id='" + parentID + "']").addClass("hidden");
        });
    });



    //menu buttons child items

$(document).ready(function () {
    $(".second-column").addClass("hidden");

    $(".first-column").mouseenter(function () {
        var category = $(this).data('category');
        var $secondColumn = $('.second-column[data-category="' + category + '"]');
        
        $('.second-column').addClass("hidden");
        // Show only the corresponding second-column element
        $secondColumn.removeClass('hidden');
    }).mouseleave(function () {
        var category = $(this).data('category');
        $('.second-column[data-category="' + category + '"]').addClass('hidden');
        
    });
});  
    // the new menu buttons


    //THE SUB-BUTTONS
    function animation1(childID) {
        var tl1 = gsap.timeline({});
        tl1.fromTo("#heading-" + childID + " .arrow", {opacity: 0}, {opacity: 1, duration: 0.2,  }, 0);
        tl1.fromTo("#heading-" + childID + " h4", {x: -10, color:"#000"}, {color:"#2B2B2B", duration:0.3,  x: 10,}, 0);  
        tl1.fromTo("#heading-" + childID + " .sub-button", { textDecoration: "none"},{duration:0.1, textDecoration: "underline",},0)
        
        return tl1;
    }
    
    $(".custHover").mouseenter(function () {
        var childID = $(this).data("category-id");
        console.log(childID);
    
        var tl1 = animation1(childID);
        tl1.play();
    }).mouseleave(function () {
        var childID = $(this).data("category-id");
        var tl1 = animation1(childID);
        tl1.time(0.5);
        tl1.reverse();
     });
     // THE SUB-BUTTONS
     




    
      if (window.matchMedia("(max-width: 992px)").matches) {
          console.log("Small screens activated");
          activateSmallScreenMenu();
      } else {
          console.log("Large screens activated");
      }
  
      
      window.matchMedia("(max-width: 992px)").addEventListener('change', function(event) {
          if (event.matches) {
              console.log("Small screens activated");
              activateSmallScreenMenu();
          } else {
            $("#menuButton").off('click');
              console.log("Large screens activated");
          }
      });
  });
  
  $(document).ready(function() {
    $(".toggleIcon").click(function() {
        $(this).toggleClass("bi-heart bi-heart-fill redText");
    });
});

$(document).ready(function(){
    $("#clickCollect").on("click", function(){
        console.log("clicked")
        $("#errorText").text("We're sorry, nothing matched your search.");
    });

    $("#gps").on("click", function(){
        console.log("clicked")
        $("#errorText").text("We're sorry, we're not currently delivering to Mars!");
    });
});

// For buttons of the carousel
$(document).ready(function () {
    var carousel = $('#carouselExample');
    carousel.carousel();

    $('.carousel-btn').click(function () {
        var slideIndex = $(this).data('slide-to');
        carousel.carousel(slideIndex);
    });
});

$(document).ready(function() {
    // Trigger the modal
    $('#exampleModalToggle').modal('show');
  });



}(jQuery));





