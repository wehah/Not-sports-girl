<?php
// --V5--

//====================================================================================
// ENQUEUES : HOOKUP JS and CSS FILES
//====================================================================================
/*
Adding <link> and <script> tags with "hard links" to CSS and JS files can cause conflicts, difficult path setup and more. 
The code below uses the 'enqueues' system to tell wordpress what files we want to hook up to our page. 
Wordpress will then create the <link> and <script> tags  
note. add google fonts using @import in style.css
*/

// functions.php

function enqueues() {
    // CSS files. Create links to bootstrap.css and style.css
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/libs/bootstrap.css', false, '3.3.4', null);
    wp_enqueue_style('festival', get_stylesheet_uri());

    // JS files. create links to jQuery and Bootstrap JavaScript.
    wp_enqueue_script('jquery');
    wp_enqueue_script('bootstrap-js', get_template_directory_uri() . '/libs/bootstrap.bundle.js', array('jquery'), null, true);

    // GSAP
    wp_enqueue_script('gsap', get_template_directory_uri() . '/js/gsap.min.js', array(), '3.12.4', true);
    wp_enqueue_script('gsap', get_template_directory_uri() . '/js/CustomEase.min.js', array(), '3.12.4', true);


    // JS files. our scripts.js file
    wp_enqueue_script('scripts-js', get_template_directory_uri() . '/js/scripts.js', array('jquery'), null, true);

    // Localize the script with new data
    $script_data = array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'ajax_handler_url' => get_template_directory_uri() . '/ajax-handler.php' // Corrected line
    );
    wp_localize_script('scripts-js', 'ajax_object', $script_data);
}

add_action('wp_enqueue_scripts', 'enqueues');

















//====================================================================================
// ENQUEUES : SENDING FILE PATHS TO JAVASCRIPT 
//====================================================================================
/*
access to files in my theme folder with javascript.

https://wordpress.stackexchange.com/questions/89791/theme-path-in-javascript-file

i can access the path to my theme folder by calling  wpPath.theme

console.log(wpPath.theme)
*/

function sendDataToJS() {
   $pathJS = array( 'theme' => get_template_directory_uri() );
   wp_localize_script( 'scripts-js', 'wpPath', $pathJS );
}











//====================================================================================
// ENQUEUES : WRITING THE LINK AND SCRIPT TAGS IN OUR TEMPLATES - cleanup wp-head
//====================================================================================
/*
to get wordpress to write out all the necessary <link> and <script> tags for our 'enqueued' files, we use a couple of wordpress tags in the templates. 
To inject all the <link> and <script> tags into the <head> of our page, we use  <?php wp_head(); ?> in header.php :

<head>
   <?php wp_head(); ?>
</head>

Hooking up our javascript requires adding <script> tags to the bottom of our page, just above the closing <body> tag. for this, we use the <?php wp_footer(); ?> tag above our closing <body> tag in footer.php : 

      <?php wp_footer(); ?>
   </body>
</html>

wp_head() will add a lot of redundant garbage links that we don't want or use, stuff like <LINK> tags to wordpress RSS feeds,and so on. 

this code strips out the redundant links we dont use or need
https://scotch.io/tutorials/removing-wordpress-header-junk
*/

function no_generator()  { return ''; }
add_filter( 'the_generator', 'no_generator' );	

remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'feed_links', 2);
remove_action('wp_head', 'feed_links_extra', 3);
remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
remove_action('wp_head', 'adjacent_posts_rel_link', 10, 0);
remove_action('wp_head', 'wp_shortlink_wp_head', 10, 0);
remove_action('wp_head', 'start_post_rel_link', 10, 0);
remove_action('wp_head', 'parent_post_rel_link', 10, 0);
remove_action('wp_head', 'rest_output_link_wp_head', 10 );
remove_action('wp_head', 'wp_oembed_add_discovery_links', 10 );
remove_action('wp_head', 'print_emoji_detection_script', 7 );
remove_action('wp_head', 'wp_resource_hints', 2 );
remove_action('wp_print_styles', 'print_emoji_styles' );

function removeWidgetStyle() {  
   global $wp_widget_factory;  
   remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );  
}  
add_action( 'widgets_init', 'removeWidgetStyle' );














//====================================================================================
// WIDGETS : ENABLE WIDGETS 
//====================================================================================
/* 
The dashboard does not provide any widget editing tools by default. We have to specifically tell wordpress we want the tools to be available to users in the admin panel. THE enableWidgets() function below activates the Dashboard > Appearence > Widgets panel, giving users the ability to choose widgets.

To control where the widget will actually appear on the website, we need to add  the  <?php dynamic_sidebar( 'widgets' ); ? > tag to one of our templates, at the location we want the snippet content to appear on our site. Wordpress will dump all the html needed to display the snippet there. Yay wordpress! 

add to one of our templates   ---->      <?php dynamic_sidebar( 'widgets' ); ? >

*/
function enableWidgets() {

	register_sidebar( array(
		'name'          => 'Widget Menu',
		'id'            => 'widgets',
		'before_widget' => '<div class = "block">',
		'after_widget'  => '</div>',
		'before_title'  => '<h2 class="white">',
		'after_title'   => '</h2>',
	) );
}

add_action( 'widgets_init', 'enableWidgets' );


















//====================================================================================
// FEATURED IMAGES : ENABLE FEATURED IMAGE THUMBNAILS 
//====================================================================================
/* 

By default, The dashboard "Edit Post" screen not provide the option for adding a featured image by default. 
We have to specifically tell wordpress we want the "add featured image" panel to be available to users in the "Edit Post" screen. 
To actually display the featured image on our website, add this tag to the loop   ----->  echo get_the_post_thumbnail(get_the_ID()); 
https://codex.wordpress.org/Post_Thumbnails
*/

add_theme_support( 'post-thumbnails' ); 


















//====================================================================================
// WP ADMIN : DISABLE THE  ADMIN TOOLBAR
//====================================================================================
/*sometimes that admin bar overlaps the navigation bar at the top page content and is annoying. 
  un comment the line below to remove the  admin toolbar from top of page when logged in.
  */

// add_filter('show_admin_bar', '__return_false');

 
 /* alternatively if you want to keep the admin toolbar and fix it so it does not overlap add CSS to style.css
 wp adds a class called .customize-support  to the body tag when the admin bar strap is added
 so we can add some css to that class to push our page content down by adding a margin-top to that class in style.css
  
.customize-support .navbar-fixed-top {
   margin-top: 30px !important;
}

 as per these articles..
 
 https://www.sitepoint.com/getting-sticky-headers-wordpress-admin-bar-behave/
 https://teamtreehouse.com/community/is-there-a-way-to-push-the-content-of-a-wordpress-site-below-the-wp-adminbar-so-it-wont-hide-my-menu-when-logged-in
 note though in these articles state that wp adds a class called .admin-bar to the body tag. for this theme though the class is .customize-support 
 check style.css to see the css used in this theme to do this 

 */

















//====================================================================================
// CATEGORIES : DESELECT 'UNCATEGORIZED' OPTION IF ANOTHER CATEGORY IS SELECTED 
//====================================================================================
/* 
by default, wordpress sets all posts to an 'uncategorized' category when they are created which is just fine.   When a new category is selected, the post also stays in the 'uncategorized' category. This is bad UX. When a post is assigned to a category, it should automatically be taken out of the 'uncategorized' category, right? 
*/

//https://www.geekwire.com/devblog/removing-default-category-wordpress-automatically-time-publishing/
//remove default category (uncategorized) when another category has been set
function remove_default_category($ID, $post) {
    //get all categories for the post
    $categories = wp_get_object_terms($ID, 'category');
    //if there is more than one category set, check to see if one of them is the default
    if (count($categories) > 1) { 
        foreach ($categories as $key => $category) {
            //if category is the default, then remove it
            if ($category->name == "Uncategorized") {
                wp_remove_object_terms($ID, 'uncategorized', 'category');
            }
        }
    }
}
//hook in to the publsh_post action to run when a post is published
add_action('publish_post', 'remove_default_category', 10, 2);


















//====================================================================================
// CATEGORY TEMPLATES : MAKE CHILD CATEGORIES USE PARENT CATEGORY TEMPLATE
//====================================================================================
/*
By default, when we click on a link to display a CATEGORY, wordpress automagically finds a template to display the content. 
For example, say we have a collection of posts in a category called "events" and we click on a link to www.mysite.com/events. 
Wordpress will look for a template with a filename "category-events.php". If it can't find that template,  it will use the default category template "category.php".

This function modifies this behaviour slightly when dealing with templates for sub-categories.

For example I have a parent category called  "events" with 'seminars' and 'exhibitions' as child categories. 
default behaviour of wordpress would cause it to look for the following templates to display posts : 

 LINK                                                                                   
 www.mysite.com/events        category-events.php    
 www.mysite.com/seminars      category-seminars.php
 www.mysite.com/exhibitions   category-exhibitions.php

 I don't want to create three separate templates for events and it's children. 
 This function will cause wordpress to use a parent category template to display child categories

 www.mysite.com/events        category-events.php 
 www.mysite.com/seminars      category-events.php
 www.mysite.com/exhibitions   category-events.php

*/

function new_subcategory_hierarchy() { 
    $category = get_queried_object();

    $parent_id = $category->category_parent;

    $templates = array();

    if ( $parent_id == 0 ) {
        // Use default values from get_category_template()
        $templates[] = "category-{$category->slug}.php";
        $templates[] = "category-{$category->term_id}.php";
        $templates[] = 'category.php';     
    } else {
        // Create replacement $templates array
        $parent = get_category( $parent_id );

        // Current first
        $templates[] = "category-{$category->slug}.php";
        $templates[] = "category-{$category->term_id}.php";

        // Parent second
        $templates[] = "category-{$parent->slug}.php";
        $templates[] = "category-{$parent->term_id}.php";
        $templates[] = 'category.php'; 
    }
    return locate_template( $templates );
}

add_filter( 'category_template', 'new_subcategory_hierarchy' );


















//====================================================================================
// SINGLE POST TEMPLATES :  ENABLE TEMPLATES FOR POSTS IN SPECIFIC CATEGORIES
//====================================================================================
/*
V2 WITH bugfix for posts that are in multiple categories

http://www.wpbeginner.com/wp-themes/create-custom-single-post-templates-for-specific-posts-or-sections-in-wordpress/
https://bloggertowp.org/tutorials/user-guide/permalinks-and-slugs/

We want to control how single posts are displayed. Specifically, we want to lay out single posts from our events category in a certain way, and single posts from our speakers category in a different layout. So we need a specific template for each.

Wordpress does have an automagic way of selecting a specific template when we want to display a COLLECTION of posts in a certain category. So if we wanted to, for example, have a specific template for displaying a bunch of posts in a an 'events' category, all we need to do is add a template named category-events.php to our theme folder and voila! whenever the browser is asked to display www.mysite.com/events/ that template will be picked up and used, No code needed, it just works. 

Sadly, it does not 'just work' when we want a specific template for showing a SINGLE post in a certain category. Wordpress uses the single.php template, all the time, regardless of which category that post is in. Hmm. What we want is to be able to create specific templates for SINGLE posts in a certain category, just like we can for displaying COLLECTIONS of posts in a certain category. 

The code below provides the same automagic template selection for single posts. To get it to work, we name our new templates for single posts like so : single-[ourcategoryslug].php. For example if you have an 'events' category and a 'speakers' category, and want specific templates for displaying single posts in each : 

single-events.php 
single-speakers.php 

remember we need the category SLUG here, not the category NAME. We can find the slug for our category in 
dashboard > categories > edit category.
*/


function registerSinglePostTemplateForSpecificCategory($single) {
   global $wp_query, $post;
   foreach((array)get_the_category() as $cat) : 
      if(file_exists(get_template_directory() . '/single-' . $cat->slug . '.php')) 
         return get_template_directory() . '/single-' . $cat->slug . '.php'; 
   endforeach; 
   return get_template_directory() . '/single.php'; 
}

add_filter('single_template', 'registerSinglePostTemplateForSpecificCategory');






















//====================================================================================
// NAVIGATION : ENABLE WORDPRESS DYNAMIC NAVBAR
//====================================================================================
//This allows users to configure menus via  Dashboard > Appearence > Menus panel.

 function registerMenu() {
    register_nav_menu('MainNavBar',__('Main Navigation Bar')); 
}   

add_action( 'init', 'registerMenu' );


//====================================================================================
// NAVIGATION : CLEANUP WORDPRESS DYNAMIC NAVBAR
//====================================================================================
// Remove wordpress generated IDs and class names from menu items

// http://stackoverflow.com/questions/5222140/remove-li-class-id-for-menu-items-and-pages-list
//
//function strip($var) {return is_array($var) ? array() : '';}

//add_filter('nav_menu_css_class', 'strip', 100, 1); // MUST DISABLE PC ERROR
//add_filter('nav_menu_item_id', 'strip', 100, 1);//MUST DISABLE PC ERROR

add_filter('page_css_class', 'strip', 100, 1);

// Remove Empty Class attributes, 'current-menu-item' and 'active' classes.
   function strip_empty_classes($menu) {
         $menu = preg_replace('/active/','',$menu);
         $menu = preg_replace('/ class=" "/','',$menu);
         $menu = preg_replace('/ id=" "/','',$menu);   
          return $menu;
    }
    
 add_filter ('wp_nav_menu','strip_empty_classes',101,1);


//====================================================================================
//  NAVIGATION : REFORMAT OUTPUT TO BE COMPATIBLE WITH BOOTSTRAP
//====================================================================================
/*
This code reformats the default HTML generated by wordpress to create a bootstrap navbar

https://github.com/twittem/wp-bootstrap-navwalker 

*/

function register_navwalker(){
	require_once get_template_directory() . '/libs/class-wp-bootstrap-navwalker.php';
}

add_action( 'after_setup_theme', 'register_navwalker' );








// MY CUSTOM BOOTSRAP MENU
function register_bootstrap_menu() {
    register_nav_menu('bootstrap-menu', __('Bootstrap Menu'));
}

add_action('init', 'register_bootstrap_menu');





add_action('init', 'add_after_pay_to_posts');

function add_after_pay_to_posts() {
  global $wpdb;
  $after_pay = 'Or 4 interests free payments of';
  $post_ids = $wpdb->get_col("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'post' AND post_status = 'publish'");

  foreach ($post_ids as $post_id) {
    update_post_meta($post_id, 'after_pay', $after_pay);
  }
}


//DELETING A SHARED CUSTOM FIELD
// global $wpdb;

// $query = "DELETE FROM {$wpdb->postmeta} WHERE meta_key = 'shared_value'";
// $wpdb->query($query);



?>