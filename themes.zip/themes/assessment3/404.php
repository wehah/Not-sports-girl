<?php get_header(); ?>


<div id="hero2" class="container mt-4 hero1 ">

   <div class="row g-0 w-100">

      <div class="col-lg-2 col-md-12  d-lg-flex order-lg-0 order-2 custom_flex_direction">
         <div class="card colour1 w-25"></div>
         <div class="card colour2 w-25"></div>
         <div class="card colour3 w-25"></div>
         <div class="card colour5 w-25"></div>
      </div>

      <div
         class="col-lg-10 col-md-12 colour4 d-flex custme-flex  justify-content-center align-items-center colum order-lg-1  order-1 htags">
         <h4 class="theird_htag mt-3 text-center"> SORRY, THIS PAGE COULD NOT BE FOUND</h4>
         <h1 class="you-tag p-3">404</h1>
         <script> </script>
         <a href="#" onClick="history.back();">
            <h4 class="theird_htag mt-3 text-center text-uppercase">Go Back..</h4>
         </a>
      </div>
   </div>
</div>









<?php get_footer(); ?>