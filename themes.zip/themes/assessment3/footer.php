

<div class="container mt-3">
   <div class="row bg-black p-2 pt-5 pb-5 m-0  slickLeft">
      <!-- first col -->
      <div class="col-12 col-lg-6">
         <div class="row g-0 d-flex align-items-center">
            <div class="col-5  ">
               <h4 class="text-uppercase text-white p-2">sign up to our <br> news letter and receive
                  <br> 20% off on your order
               </h4>
            </div>
            <div class="col-7">
               <div class="input-group mb-3">
                  <input type="email" class="form-control text-uppercase p-2 rounded-0"
                     placeholder="Enter email address">
                  <button class="btn btn-primary text-uppercase p-2 bg-cust" type="submit">Submit</button>
                  <div class="row g-1 mt-1">
                     <div class="col-6"><input type="text" class="form-control text-uppercase p-2 rounded-0"
                           placeholder="Enter your name">
                     </div>
                     <div class="col-6"><input type="text" class="form-control text-uppercase p-2 rounded-0"
                           placeholder="Enter your name">
                     </div>
                  </div>
               </div>

            </div>
         </div>


      </div>

      <!-- second col -->
      <div class="col-7 col-lg-4 d-flex justify-content-lg-center pt-3 pt-lg-0">
         <div class="row">
            <div class="col-12">
               <h4 class="  text-white text-center text-uppercase">sports girl socials</h4>
               <div class="card bg-transparent border-0 dcustom">
                  <button class="border-0 p-0 m-0 bg-transparent w-25">
                     <img class="w-75 p-0"
                        src="<?php echo get_template_directory_uri(); ?>/assets/brand/Vector.png"></button>
                  <button class="border-0 p-0 m-0 bg-transparent w-25">
                     <img class="w-75 p-0"
                        src="<?php echo get_template_directory_uri(); ?>/assets/brand/Vector-1.png"></button>
                  <button class="border-0 p-0 m-0 bg-transparent w-25">
                     <img class="w-75 p-0"
                        src="<?php echo get_template_directory_uri(); ?>/assets/brand/Vector-2.png"></button>

               </div>

            </div>
            <div class="col">

            </div>
         </div>

      </div>

      <!-- third col -->
      <div class="col-5  col-lg-2 text-white d-flex justify-content-lg-center pt-3 pt-lg-0">
         <div class="">
            <h4 class="text-uppercase p-0 m-0">info</h4>
            <a class="text-white" href="<?php echo get_permalink(get_page_by_path('references','','page')); ?>">
               <p class="p-0 m-1">References</p>
            </a>
            <a class="text-white" href="<?php echo get_permalink(get_page_by_path('service-contact','','page')); ?>">
               <p class="p-0 m-1">Service & Contact</p>
            </a>
            <a class="text-white" href="<?php echo get_permalink(get_page_by_path('privacy-policy','','page')); ?>">
               <p class="p-0 m-1">Privacy Policy</p>
            </a>
         </div>
      </div>
   </div>
</div>

<hr>
<a href="mailto:garraamo@gmail.com"><h4 class="text-center mt-5 mb-5">copyright Mohamed Ali 21st Century</h4></a>

<div class="modal fade  " id="exampleModalToggle" aria-hidden="true" aria-labelledby="exampleModalToggleLabel" tabindex="-1">
   <div class="modal-dialog modal-dialog-centered modal-xl .modal-fullscreen">
     <div class="modal-content">
       <div class="modal-header">
         <h4 class="modal-title fs-5" id="exampleModalToggleLabel">Disclaimer</h4>
         <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
       </div>
       <div class="modal-body">
           <div id="hero2" class=" row g-0 w-100">
               <div class="col-lg-2 col-md-12  d-lg-flex order-lg-0 order-2 custom_flex_direction">
                  <div class="card colour1 w-25 position-relative"></div>
                  <div class="card colour2 w-25"></div>
                  <div class="card colour3 w-25"></div>
                  <div class="card colour5 w-25"></div>
               </div>
         
               <div
                  class="col-lg-10 p-3 col-md-12 colour4  order-lg-1  order-1 popUpText">
                  
        
                <h1 class="text-right"> <span class="strongText"> THIS IS NOT</span> THE OFFICIAL WEBSITE OF<br>
                   <span class="strongText">SPORTSGIRL <br></span> 
                    THIS WAS PART OF A UNI PROJECT</h1>
                  
               </div>
            </div>
       </div>
      
     </div>
   </div>
 </div>

<?php wp_footer(); ?>

</body>

</html>