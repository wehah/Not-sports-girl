<?php get_header(); ?>



<div id="products" class="container mt-5">
    <h2 class="slickBorder mb-0 p-0 pb-2 text-uppercase"> <?php single_cat_title();  ?></h2>

    <h4> </h4>

    <div class="row">

    <?php if(have_posts()) : while(have_posts()) :the_post(); ?>

    <div class="col-lg-4 col-md-6 col-sm-12 p-3 pt-2">

        <div class="row">
           <div class="col-12 carD p-0" id="cards">


              <!-- inside column without padding -->
              <a href="<?php the_permalink(); ?>">
                 <div class="card border-0 P-0"> <img class="card-img-top"
                       src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="">
                 </div>

                 <div class="card border-0">

                    <div class="row sidePadding">
                       <div class="col-9 pb-0">
                          <h4 class=" pt-2 ">
                            <?php the_title(); ?>
                          </h4>
                       </div>
                       <div class="col-3">
                        <h4 class="text-end text-stroke pt-2"> <del>
                           <?php echo get_post_meta($post->ID, 'Original price', true); ?>
                        </del>

                     </h4>


                       </div>
                    </div>
                 </div>

                 <div class="card border-0 p-0 m-0">
                    <div class="row sidePadding">
                       <div class="col-8 Pt-0">
                        <h4 class="redText">
                            SALE
                         </h4>
                       </div>
                       <div class="col-4">
                        <h4 class="text-end P-0 redText">
                            <?php echo get_post_meta($post->ID, 'Price', true); ?>
                         </h4>
                       </div>
                    </div>
                 </div>
              </a>

           </div>
        </div>

     </div>


<?php endwhile; endif; ?>
</div>


 </div>





 <?php get_footer(); ?>