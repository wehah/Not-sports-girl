<?php get_header(); ?>

<div id="searchresults" class="container mt-4">
<!-- <h2 class="text-uppercase slickBorder mb-4 p-0 pb-2">Search results</h2> -->
<h3> Search results for <?php the_search_query(); ?> </h3>
<h3><?php echo $wp_query->found_posts;?> Results</h3>
</div>

<div class="container">
    <div class="row g-1">
        <?php if(have_posts()) : while(have_posts()) :the_post(); ?>
        <div class="col-2 ">
            <a href="<?php the_permalink(); ?>"> <img class=" w-100" src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>"
                alt="">
          </a>
        </div>
        <div class="col-10 ">
            <div class="info w-50 pt-2 content">
            <a href="<?php the_permalink(); ?>"> <h4 class="text-uppercase bold-font-weight"> <?php the_title(); ?> </h4></a>
            <?php the_content(); ?>

            <h4 class="bold-font-weight m-0">
                <?php echo get_post_meta($post->ID, 'Price', true); ?>
            </h4>
            
        </div>

        </div>
        <?php endwhile; ?>
        
        <?php else: ?>

        <div class="card p-3">
            <h4 class="text-uppercase bold-font-weight">No products found!</h4>
            <p>We're sorry, nothing matched your search. Please try with different keywords</p>
        </div>

         <?php endif; ?>
    </div>
    




</div>



  




<?php get_footer(); ?>