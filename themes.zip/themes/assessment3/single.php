<?php get_header(); ?>

<div class="container mt-3"> 


    <div class="row g-0 p-0">
        <?php
        $price_raw = get_post_meta($post->ID, 'Price', true);
        
        
        
        // Remove the  non numeric (Dollar) character
        $price = floatval(preg_replace('/[^\d.]/', '', $price_raw));
        
        
        if (is_numeric($price) && $price > 0) {
            $divided_price = $price / 4;

            //Put the Dollar sign back on the devided_price & control decimal numbers
            $formatted_divided_price = '$' . number_format($divided_price, 2);    

        } else {
            var_dump('There is no product to display');
        }
        ?>



        <!-- THE CAROUSEL -->

        
          <!-- Buttons for the carousel -->
            <!-- conditional bootstrap class added to the BUTTONS col to disappear -->
        <div class="col-3 col-lg-2 p-0 h-100 <?php if (!get_post_gallery()) echo 'd-none'; ?>">
          
            <div class="row g-0">
                <?php if ( get_post_gallery() ) : ?>
                <div class="col p-0">
                    <?php $gallery = get_post_gallery( get_the_ID(), false ); ?>
                    <?php $first = true; ?>
                    <?php foreach( $gallery['src'] as $index => $src ) : ?>

                    <button class="carousel-btn border-0 p-0 m-0" data-slide-to="<?php echo $index; ?>">
                        <img class=" w-100 pb-0" src="<?php echo $src; ?>" class="d-block w-100" alt="...">
                    </button>

                    <?php endforeach; ?>
                </div>
                <?php else : ?>
                <img class="card-img h-100 object-fit-cover"
                    src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>">
                <?php endif; ?>
            </div>
        </div>


<!-- conditional bootstrap class added to this col -->
        <div class="col-9 col-lg-6 p-0 <?php if (!get_post_gallery()) echo 'col-12 col-lg-8'; ?>">

            <?php if ( get_post_gallery() ) : ?>

            <div id="carouselExample" class="carousel slide ">
                <div class="carousel-inner h-100 position-relative">

                    <?php $gallery = get_post_gallery( get_the_ID(), false ); ?>
                    <?php $first = true; ?>
                    <?php foreach( $gallery['src'] as $index => $src ) : ?>

                    <div class="h-100 carousel-item<?php if( $index === 0 ) echo ' active'; ?>">
                        <img class="d-block w-100 h-100 object-fit-cover" src="<?php echo $src; ?>" />
                        
                    </div>
                    <p class="position-absolute bottom-0  rightAlign"><?php echo get_post_meta($post->ID, 'text_citation', true); ?></p>
                    <?php endforeach;?>
                </div>

                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>

                <button class="carousel-control-next" type="button" data-bs-target="#carouselExample"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>

            </div>

            <?php else : ?>

            <img class="card-img  object-fit-cover" src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>">

            <?php endif; ?>




        </div>




        <!-- Column containing the info -->
        <div class="col-12 col-lg-4 mt-4  p-lg-4  pt-0">
            <div class="card border-0 text-uppercase">
                <h4 class="bold-font-weight">
                    <?php the_title(); ?>
                </h4>
            </div>
            <div class="card border-0 pt-0 pb-0 content">

                <?php the_content() ?>

            </div>

            <div class="card border-0 m-0 mb-2">

                <h4 class="bold-font-weight m-0">
                    <?php echo get_post_meta($post->ID, 'Price', true); ?>
                </h4>

                <p class="p-0">
                    <?php echo get_post_meta($post->ID, 'after_pay', true); ?>
                    <?php echo isset($divided_price) ? $formatted_divided_price : ''; ?> with <img
                        class="custWidth p-0 m-0"
                        src="<?php echo get_template_directory_uri(); ?>/assets/brand/log-afterpay.png"></a> <a
                        class="underline" href="https://www.afterpay.com/en-AU">more info</a>
                </p>
            </div>
            <!-- radio button -->
            <div class="card border-0 m-0 mb-2 w-100 p-0">
                <h4 class="bold-font-weight text-uppercase  p-0 m-0 pt-1 pb-1">select size</h4>
                <div class="btn-group  " role="group" aria-label="Basic radio toggle button group">
                    <input type="radio" class="btn-check" name="btnradio" id="btnradio1" autocomplete="off" checked>
                    <label class="btn btn-outline-primary rounded-0 m-1 sizeButton " for="btnradio1">
                        <h4 class="pt-2">S</h4>
                    </label>

                    <input type="radio" class="btn-check" name="btnradio" id="btnradio2" autocomplete="off">
                    <label class="btn btn-outline-primary m-1 sizeButton" for="btnradio2">
                        <h4 class="pt-2">M</h4>
                    </label>

                    <input type="radio" class="btn-check " name="btnradio" id="btnradio3" autocomplete="off">
                    <label class="btn btn-outline-primary rounded-0 m-1 sizeButton" for="btnradio3">
                        <h4 class="pt-2">L</h4>
                    </label>

                    <input type="radio" class="btn-check " name="btnradio" id="btnradio4" autocomplete="off">
                    <label class="btn btn-outline-primary rounded-0 m-1 sizeButton" for="btnradio4">
                        <h4 class="pt-2">XL</h4>
                    </label>

                </div>

            </div>
            <!-- radio button -->
            <!-- CLICK & COLLECT -->
            <div class="card border-0 m-0">
                <div class="accordion" id="accordionExample">
                    <div class="accordion-item border-1 border-black rounded-0">

                        <button class="accordion-button collapsed p-2 bg-transparent border-0 boxShadow mt-1"
                            type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false"
                            aria-controls="collapseTwo">
                            <h4 class=" text-uppercase  p-0 m-0 pt-2 pb-2"> click & collect</h4>
                        </button>

                        <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                            <div class="accordion-body border-1 pt-0">
                                <div class="row">

                                    <div class="col-12   p-0">
                                        <h4 class="p-1   m-0 text-uppercase ">Size</h4>
                                        <div class="input-group m-0 p-2 rounded-0 border border-1">
                                            <select
                                                class="form-select form-select-lg  rounded-0  singleButton textStyle text-uppercase border-0">

                                                <option selected>S</option>
                                                <option value="1">M</option>
                                                <option value="2">L</option>
                                                <option value="3">XL</option>
                                            </select>


                                        </div>



                                    </div>

                                    <div class="col-12 p-1 mt-2 ">

                                        <h4 class="p-1 m-0 text-uppercase">Find store location</h4>

                                        <div class="card w-100   bg-transparent border-0  ">
                                            <form class="custom-search-input  p-2 rounded-0" role="" action="">
                                                <input class="form-control shadow-none singleButton textStyle" type=""
                                                    name="" placeholder="Suburb or Postcode">

                                                <div class="border-0 bg-transparent p-0 m-0 widthCustm">
                                                    <img class="w-100  p-2 m-0" id="gps"
                                                        src="<?php echo get_template_directory_uri(); ?>/assets/icons/gps.png">
                                                </div>
                                            </form>

                                        </div>
                                    </div>

                                    <div class="col-12 p-1">
                                        <button type="button" id="clickCollect"
                                            class="btn btn-primary btn-lg btn-block bg-black border-0 rounded-0 w-100">
                                            <h4 class="text-uppercase p-0 m-0 pt-2 pb-2 bold-font-weight">Search
                                            </h4>
                                        </button>
                                        <p class="mt-2 text-danger" id="errorText"></p>

                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
                <!-- CLICK & COLLECT -->

                <div class="card mt-2 w-100 p-0">
                    <button type="button" class="btn btn-primary btn-lg btn-block bg-black border-0 rounded-0">
                        <h4 class="text-uppercase p-0 m-0 pt-2 pb-2 bold-font-weight">add to bag</h4>
                    </button>
                </div>
            </div>
        </div>



    </div>
</div>



    <?php get_footer(); ?>