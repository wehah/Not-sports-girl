<?php get_header(); ?>

<!-- ================================================================================== -->

<!-- hero-1 -->

<!-- ================================================================================== -->

<div id="hero" class="container    mt-3 hero1">
   
      <div class="row g-0 w-100">

         <div class="col-lg-2 col-md-12  d-lg-flex order-lg-0 order-2 custom_flex_direction">
            <div class="card colour1 w-25"></div>
            <div class="card colour2 w-25"></div>
            <div class="card colour3 w-25"></div>
            <div class="card colour4 w-25"></div>

         </div>
         
         <div class="col-lg-4 col-md-12 colour5  order-lg-1  order-1  d-flex custme-flex  justify-content-center align-items-center">
            <a class="w-100 d-flex custme-flex  justify-content-center align-items-center colum" href="category/featured"> 
            <h4 class="first_htag text-start ">HERE'S </h4>
            <h4 class="">TO</h4>
            <h1 class="you-tag">YOU</h1>
            <h4 class="theird_htag mt-3 text-center"> SHOP OUR LATEST COLLECTION</h4>
         </a>
         </div>
     

         <div class="col-lg-6 col-md-12 order-lg-2 order-0">
            <?php
            $args = array(
              'category_name' => 'featured',
              'posts_per_page' => -1, // Get all posts in the category
            );
            $posts = get_posts($args);
            if ($posts):
              ?>
              <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
                <div class="carousel-indicators">
                  <?php for ($i = 0; $i < count($posts); $i++): ?>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo $i; ?>" <?php if ($i === 0): ?>class="active" aria-current="true"<?php endif; ?> aria-label="Slide <?php echo $i + 1; ?>"></button>
                  <?php endfor; ?>
                </div>
                <div class="carousel-inner">
                  <?php foreach ($posts as $key => $post) :
                    setup_postdata($post);
                    $product_image = get_the_post_thumbnail_url(get_the_ID());
                    ?>
                    <div class="carousel-item <?php if ($key === 0) echo 'active'; ?>">
                      <a class="" href="<?php the_permalink(); ?>"><img src="<?php echo $product_image; ?>" class="d-block w-100" alt="<?php the_title(); ?>">
                    </a></div>
                  <?php endforeach; ?>
                  <?php  wp_reset_postdata();  ?>
                </div>
              </div>
              <?php
              wp_reset_postdata(); 
            endif;
            ?>
         </div>
      </div>

      <!-- <h1 class="display-4">The ShopFront</h1>
   <p class="lead ">Welcome to the store</p> -->
   
</div>



<!-- =============================CONTENTS============================================= -->
<!-- ================================================================================== -->

<!-- CATEGORIES -->

<!-- ================================================================================== -->

<div id="categories" class="container mt-4">
   <h2 class="slickBorder mb-1 p-0 pb-2">THE<br>HOTTEST<br>CATEGORIES</h2>
   <div class="row  g-2">

      <?php
      $args = array(
          'category_name' => 'top_categories',
          'posts_per_page' => 4,
      );
      $posts = get_posts($args);
      
      if ($posts):
          foreach ($posts as $post) :
              setup_postdata($post);
      
              // Get the post's category ID
              $categories = get_the_category($post->ID);
              $category_id = $categories[0]->cat_ID;
      
              // Get the category link using the category ID
              $category_link = get_category_link($category_id);
      
              // Use the category ID and category link as needed
             
?>

      <div class="col-lg-3 col-md-6  overflow-hidden">
         <a href="category/<?php the_title(); ?>">
            <div class="card  card_image  h-100 position-relative col-category border-0  cards pt-0"><img
                  class="card-img-top" src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="">
               <div class="card  innerCard border-0 bag-custom1   position-absolute w-100 h-25"
                  style="background-color: <?php echo get_post_meta($post->ID, 'colour', true); ?>;">
                  <h4 class="pt-4 text-center text-uppercase">
                     <?php the_title(); ?>
                  </h4>
               </div>
            </div>
         </a>
      </div>


      <?php
      endforeach;
      wp_reset_postdata(); // Reset post data after the loop
   endif;
   ?>

   </div>
</div>
<!-- =============================CONTENTS============================================= -->
<!-- ================================================================================== -->

<!-- PRODUCTS -->

<!-- ================================================================================== -->


<div id="products" class="container mt-4">
   <a href="category/featured-products"><h2 class="slickBorder mb-0 p-0 pb-2">WHAT'S<br> HOT NOW</h2></a>

   <div class="row g-3">
      <?php
         $args = array(
            'category_name' => 'products',
            'posts_per_page' => 6,
         );
         $posts = get_posts($args);
         if ($posts):
            foreach ($posts as $post) :
               setup_postdata($post);
         ?>


      <!-- outside column with padding -->
      <div class="col-lg-4 col-md-6 col-sm-12 p-3 pt-2">

         <div class="row">
            <div class="col-12 carD p-0" id="cards">


               <!-- inside column without padding -->

               <div class="card border-0 P-0 position-relative">
                  <a href="<?php the_permalink(); ?>"> <img class="card-img-top svgparent"
                        src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="">
                  </a>

                  <i class="bi bi-heart  position-absolute toggleIcon"></i>
               </div>

               <div class="card border-0">

                  <div class="row sidePadding">
                     <div class="col-9 pb-0">
                        <h4 class="blueText pt-2 ">
                           NEW
                        </h4>
                     </div>
                     <div class="col-3">
                        <h4 class="text-end text-stroke p-0">

                        </h4>


                     </div>
                  </div>
               </div>

               <div class="card border-0 p-0 m-0">
                  <div class="row sidePadding">
                     <div class="col-8 Pt-0">
                        <h4 class="">
                           <?php the_title(); ?>
                        </h4>
                     </div>
                     <div class="col-4">
                        <h4 class="text-end P-0">
                           <?php echo get_post_meta($post->ID, 'Price', true); ?>
                        </h4>
                     </div>
                  </div>
               </div>


            </div>
         </div>

      </div>

      <?php
         endforeach;
         wp_reset_postdata(); // Reset post data after the loop
      endif;
      ?>

   </div>

</div>

<!-- ================================================================================== -->

<!-- hero 2 -->

<!-- ================================================================================== -->
<div id="hero2" class="container mt-4 hero1">
   <a href="category/sale">
      <div class="row g-0 w-100">

         <div class="col-lg-2 col-md-12  d-lg-flex order-lg-0 order-2 custom_flex_direction">
            <div class="card colour1 w-25"></div>
            <div class="card colour2 w-25"></div>
            <div class="card colour3 w-25"></div>
            <div class="card colour5 w-25"></div>

         </div>

         <div
            class="col-lg-4 col-md-12 colour4 d-flex custme-flex  justify-content-center align-items-center colum order-lg-1  order-1 htags">
            <h4 class="first_htag text-center ">30% </h4>
            <h4 class="off">OFF</h4>
            <h1 class="you-tag">NOW</h1>
            <h4 class="theird_htag mt-3 text-center"> EXPLORE DISCOUNTED ITEMS</h4>
         </div>

         <div class="col-lg-6 col-md-12 order-lg-2 order-0">
            <?php
            $args = array(
              'category_name' => 'sale',
              'posts_per_page' => -1, // Get all posts in the sale category
            );
            $posts = get_posts($args);
            if ($posts):
              ?>
              <div id="carousel-2" class="carousel slide" data-bs-ride="carousel" data-bs-interval="3000">
               <div class="carousel-indicators">
                 <?php for ($i = 0; $i < count($posts); $i++): ?>
                   <button type="button" data-bs-target="#carousel-2" data-bs-slide-to="<?php echo $i; ?>" <?php if ($i === 0): ?>class="active" aria-current="true"<?php endif; ?> aria-label="Slide <?php echo $i + 1; ?>"></button>
                 <?php endfor; ?>
               </div>
             
               <div class="carousel-inner">
                 <?php foreach ($posts as $key => $post) :
                   setup_postdata($post);
                   $product_image = get_the_post_thumbnail_url(get_the_ID());
                   ?>
                   <div class="carousel-item <?php if ($key === 0) echo 'active'; ?>">
                     <img src="<?php echo $product_image; ?>" class="d-block w-100" alt="<?php the_title(); ?>">
                   </div>
                 <?php endforeach; ?>
                 <?php  wp_reset_postdata();  ?>
               </div>
             </div>
             
              <?php
              wp_reset_postdata(); 
            endif;
            ?>
         </div>
      </div>

      <!-- <h1 class="display-4">The ShopFront</h1>
      <p class="lead ">Welcome to the store</p> -->
   </a>
</div>


<!-- =============================CONTENTS============================================= -->
<!-- ================================================================================== -->

<!-- PRODUCTS 2 -->

<!-- ================================================================================== -->


<div id="products2" class="container mt-4">
   <a href="category/sale"><h2 class="slickBorder mb-0 p-0 pb-2">ON SALE<br> GRAB A BARGAIN</h2></a>

   <div class="row g-3 ">
      <?php
         $args = array(
            'category_name' => 'sale',
            'posts_per_page' => 3,
         );
         $posts = get_posts($args);
         if ($posts):
            foreach ($posts as $post) :
               setup_postdata($post);
         ?>


      <!-- outside column with padding -->
      <div class="col-lg-4 col-md-6 col-sm-12 p-3 pt-2 ">

         <div class="row">
            <div class="col-12 carD p-0" id="cards">
               <!-- inside column without padding -->
               <div class="card border-0 P-0 ">
                  <a href="<?php the_permalink(); ?>"> <img class="card-img-top "
                        src="<?php echo get_the_post_thumbnail_url(get_the_ID()); ?>" alt="">
                  </a>
                  <i class="bi bi-heart  position-absolute toggleIcon"></i>
               </div>

               <div class="card border-0">

                  <div class="row sidePadding">
                     <div class="col-9 pb-0">
                        <h4 class="pt-2 text-uppercase">
                           <?php the_title(); ?>
                        </h4>
                     </div>
                     <div class="col-3 discounted">
                        <h4 class="text-end text-stroke pt-2"> <del>
                              <?php echo get_post_meta($post->ID, 'Original price', true); ?>
                           </del>
                        </h4>
                     </div>
                  </div>
               </div>

               <div class="card border-0 p-0 m-0">
                  <div class="row sidePadding">
                     <div class="col-8 Pt-0">
                        <h4 class="redText">
                           SALE
                        </h4>
                     </div>
                     <div class="col-4">
                        <h4 class="text-end P-0 redText">
                           <?php echo get_post_meta($post->ID, 'Price', true); ?>
                        </h4>
                     </div>
                  </div>
               </div>


            </div>
         </div>

      </div>

      <?php
         endforeach;
         wp_reset_postdata(); // Reset post data after the loop
      endif;
      ?>

   </div>

</div>

<!-- menu to delete -->



<?php get_footer(); ?>